# nalarch — comment ça marche

Le README dit ce que fait nalarch et comment le lancer. Ceci dit pourquoi il
fonctionne ainsi : les écrans en détail, l'analyse qui les alimente, et le
raisonnement derrière les choix que le code ne montre pas.

*[English version](design.md) — version de référence · [retour au README](../README.fr.md).*

## Les trois écrans

**Tableau** → **Résumé** → **Exécution**. Rien ne se lance sans passer par le résumé.

### L'écran de résumé

C'est la raison d'être de nalarch. Un gestionnaire de paquets affiche bien tout ce qu'il
faut savoir, mais mêlé à des centaines de lignes de journal : on finit par ne plus rien lire
et valider en espérant. Ici tout tient sur un écran.


Les **nouveaux paquets** sont l'apport le moins visible et le plus utile : `checkupdates`
ne montre que les paquets déjà installés qui ont une version plus récente, jamais les
dépendances qu'une mise à jour tire au passage. nalarch les obtient avec
`pacman -Sup --print-format`, exécuté sur la base temporaire de `checkupdates` — données
fraîches, aucun privilège, aucune écriture.

Les catégories reprennent celles de nala (`Operation` dans `src/libnala/transaction.rs`),
adaptées à pacman : mises à jour, nouveaux paquets, retours arrière, suppressions, retraits
en cascade, et paquets figés — l'équivalent de son `Held`.

Les **retraits en cascade** sont le pendant, côté suppression, des nouvelles dépendances :
`-Rns` emporte les dépendances devenues inutiles, et c'est souvent le gros de l'opération.
Retirer `asciiquarium` emporte `perl-term-animation` et `perl-curses` — 789 Kio au lieu des
28 Kio du paquet coché. La liste vient de `pacman -Rsp`, un essai à blanc sans privilège.
(`-n` et `-p` sont incompatibles dans pacman ; l'omettre est sans effet sur la liste, `-n`
ne portant que sur les fichiers de configuration.)

Les **points d'attention** sont calculés, pas décoratifs. Sont détectés : compilation depuis
l'AUR (un PKGBUILD est du code non relu exécuté sous ton compte), mise à jour partielle,
mise à jour du noyau et modules DKMS à recompiler, composants système essentiels, retour à
une version antérieure, nouvelles dépendances, mises à jour figées par `IgnorePkg`. Pour une
suppression : paquets encore réclamés par d'autres, et le rappel que les greffons chargés à
l'exécution sont invisibles.

Règle suivie : n'annoncer que ce qui est **vérifié**. Un avertissement approximatif
s'ignore vite, et une liste qu'on ignore ne protège de rien.

### L'écran d'exécution

Structuré en blocs, comme celui de nala : ce qui se télécharge, ce qui s'exécute, puis ce
qu'il reste à savoir. Chaque bloc porte sa propre barre, parce qu'il n'existe pas
d'avancement unique — téléchargement et installation sont deux décomptes distincts, et les
mêler donnerait un chiffre qui ne veut rien dire.


Avant tout cela, paru a parfois sa propre résolution à montrer. Installer un paquet AUR est
le cas où le plan de nalarch est sciemment incomplet : pacman ne sait pas résoudre
`plakar-git`, donc le plan annonce « 1 paquet, tailles inconnues » pendant que paru établit
que `go` doit venir avec pour le compiler. paru l'imprime dans une table et demande de
confirmer — et tant qu'elle n'était pas lue, la transcription affichait `Opérations · 0` et la
confirmation demandait d'approuver ce que rien à l'écran n'avait montré. Elle est désormais
racontée comme le reste, les dépendances de compilation signalées comme telles :

```
┌ paru a résolu · 2 paquet(s) ─────────────────────────────────────────────┐
│ ⚒ extra      go                    2:1.26.6-1  pour la compilation seule │
│ + aur        plakar-git            1.0.3.r384.gd77c14a2-1                │
└──────────────────────────────────────────────────────────────────────────┘
```

Les cibles sont passées à paru qualifiées par leur dépôt — `aur/plakar`, `extra/ripgrep` —
et avec `--noprovides`.

Le préfixe seul ne suffit pas. `paru -S plakar` est ambigu parce que `plakar-git` fournit
`plakar` lui aussi, et `aur/plakar` restreint le dépôt sans toucher à la recherche de
fournisseurs : paru demande toujours lequel on veut, après que le choix a été fait en cochant
une ligne. `--provides` couvre « les cibles et les paquets manquants » ; ici les cibles
viennent toujours d'une liste de noms réels, cette moitié-là n'est donc que du bruit.

L'autre moitié est le coût, et il est dit plutôt que caché : une dépendance qu'aucun paquet ne
satisfait par son nom échoue désormais à se résoudre au lieu de proposer un menu. Cet échec est
bruyant et atterrit dans la liste des erreurs, là où la question était silencieuse et survenait
à chaque installation ambiguë.

paru pose aussi des questions numérotées, et celles-là étaient pires : `Enter a number
(default=1):` n'a ni crochets ni point d'interrogation, elle n'était donc pas reconnue comme
une invite du tout. nalarch annonçait que rien n'était attendu pendant que paru restait bloqué
sur un choix de fournisseur. Un deux-points final compte désormais comme une question — ce
qui n'est sûr que parce qu'on inspecte la ligne où se trouve le curseur, et que tout ce
qu'imprime pacman se termine par un saut de ligne. Le curseur reste sur une invite justement
parce qu'une invite n'en a pas.

```
┌ paru demande · quel plakar ? ────────────────────────────────────────────┐
│ 1 plakar             AUR    ← Entrée prend celui-ci                      │
│ 2 plakar-git         AUR                                                 │
└──────────────────────────────────────────────────────────────────────────┘
```

La question est conservée plutôt que recalculée à chaque image, mais son texte est lu en
direct. Conserver le texte aussi figeait la question à l'instant de son apparition : une
réponse en train d'être tapée n'apparaissait donc nulle part, quatre appuis sur `1`
ressemblaient exactement à aucun, et le seul moyen de les voir était la sortie brute de paru —
la vue que la transcription existe pour remplacer. Un mot de passe n'est pas renvoyé en écho :
sa ligne reste la question, ce qui est la chose honnête à montrer. La détection lit la
ligne où se trouve le curseur, et le premier caractère d'une réponse s'affiche sur cette même
ligne — la forme cesse donc de correspondre dès qu'on tape, et « saisie attendue » disparaissait
pendant que paru attendait toujours. Elle est effacée à l'arrivée d'une ligne complète, ce qui
ne survient qu'une fois que paru a quelque chose de nouveau à dire.

Ce même saut de ligne manquant explique que le choix par défaut soit lu sur l'écran émulé
plutôt que dans le flux : le découpeur garde une ligne inachevée dans son tampon et ne l'émet
jamais.

Les lignes sont groupées plutôt que listées. Une liste plate laissait `go` sans raison
donnée — du point de vue du lecteur, aussi bien un bug qu'une dépendance de compilation. Ce
que deviennent ces dépendances ensuite est lu dans la configuration de paru plutôt que
supposé : `RemoveMake` est un réglage par utilisateur, et une dépendance de compilation peut
être six cents mégaoctets de compilateur — la différence entre « retirée » et « reste
installée » mérite d'être dite juste.

Les colonnes de cette table sont alignées et non délimitées : ses lignes se lisent donc par la
forme — le premier champ porte `dépôt/nom`, un `Yes`/`No` final est l'indicateur de
compilation seule, et ce qui reste est une version pour une installation, deux pour une mise
à jour.

Le bloc **À noter** rassemble ce qui demande une action de ta part et que la sortie noie :
fichiers `.pacnew` à fusionner, redémarrage nécessaire, avertissements, erreurs. Chaque
entrée dit quoi faire, pas seulement ce qui s'est passé — un `.pacnew` s'accompagne de la
commande `sudo pacdiff -s` et du rappel que sans elle, la nouvelle configuration ne
s'applique jamais.

La sortie détaillée de paru reste accessible par `j`, y compris une fois l'opération
terminée. Le
redémarrage se déduit du plan — pacman ne le signale pas, et le symptôme arrive bien plus
tard, quand plus rien ne le relie à la mise à jour.

### Locale figée

Le processus tourne avec `LC_ALL=C`. Analyser une sortie traduite serait intenable : chaque
langue change les verbes, et une mise à jour de traduction casserait le parsing en silence.
En anglais le vocabulaire est stable, tiré directement des chaînes de pacman.

Rien de cet anglais n'atteint l'écran : `src/journal.rs` réécrit tout — les phases, les
actions, et les avertissements courants. Un message non reconnu passe tel quel, parce qu'une
phrase anglaise vaut mieux qu'une information perdue.

makepkg est la source la plus bruyante du flux et a demandé trois choses à lui seul. Ses
remises à zéro de couleur se terminent par `ESC ( B`, une désignation de jeu de caractères sur
deux octets : n'en retirer qu'un laissait le `B`, et chaque étape s'affichait « Checking
sources...B ». Ses avertissements et ses erreurs arrivent par le même marqueur `==>` que ses
étapes, et classés comme étapes ils se noyaient parmi quarante autres au lieu d'aller dans
**À noter**. Et une compilation n'a pas d'avancement chiffrable : le compteur hérité de la
phase précédente doit donc disparaître — conservé, il figeait la barre à 0,0 % pendant des
minutes, ce qui se lit comme bloqué plutôt que comme non mesurable.

C'est cette analyse qui permet la transcription. nalarch ne retenait auparavant qu'un
compteur et une phase : de quoi remplir une barre, pas de quoi raconter l'opération.

## Voir ce que change une mise à jour

Touche `c` sur un paquet de l'onglet **Mises à jour**.

Une transition de version ne dit rien de ce qu'elle apporte, et les paquets Arch n'embarquent
presque jamais de changelog — `pacman -Qc` est vide la plupart du temps. L'information existe
ailleurs, à deux endroits complémentaires :

```
 fastfetch   2.66.0-1 → 2.67.1-1
 amont : https://github.com/fastfetch-cli/fastfetch
┌ Changements ────────────────────────────────────────────────────┐
│ Journal de packaging Arch                                       │
│  ▸ 2026-08-14  2.67.1-1: New upstream release                   │
│  ▸ 2026-08-06  2.67.0-1: New upstream release                   │
│    2026-07-10  2.66.0-1: New upstream release                   │
│    ─── version installée ───                                    │
│                                                                 │
│ Notes de version amont · 2.67.1                                 │
│  Bugfixes:                                                      │
│  • Fixed a `Symbol not found` error on macOS 10.15              │
└─────────────────────────────────────────────────────────────────┘
```

Le **journal de packaging** dit *pourquoi* le paquet bouge : nouvelle version amont, ou
simple reconstruction contre une bibliothèque. C'est souvent la réponse la plus utile — une
reconstruction n'apporte aucune fonctionnalité et explique une mise à jour qui paraissait
gratuite. Les entrées marquées `▸` sont celles qu'apporte la mise à jour ; sous le trait,
c'est déjà installé.

La ligne au-dessus est celle qu'il faut lire en premier : la mise à jour apporte-t-elle une
nouvelle version amont, seulement. Une révision de paquetage seule — `6.29.0-1 → 6.29.0-2` —
signifie une reconstruction, un correctif d'empaquetage ou un changement de dépendance, jamais
une fonctionnalité. C'est la réponse la plus fréquente et la plus difficile à lire dans une
liste de commits : elle est donc dite, pas laissée à déduire.

Les **notes de version amont** viennent de GitHub, qui couvre un peu moins de la moitié de ce
qui est installé sur une machine ordinaire, et des instances GitLab — GNOME, freedesktop,
l'invent de KDE — qui couvrent une bonne part du reste. Les deux API répondent à la même
question : prendre en charge la seconde ne coûte qu'une forme de requête de plus. Une instance
GitLab ne se reconnaît pas à son nom d'hôte : seuls les hôtes qui apparaissent réellement comme
URL amont sont acceptés, car deviner reviendrait à interroger un serveur sans rapport pour
chaque paquet. Un paquet AUR n'a pas de dépôt de packaging : c'est le
PKGBUILD qui fait foi, et paru propose de le relire avant de compiler.

Les requêtes passent par `curl` dans un fil séparé — l'interface ne se fige pas, et ça évite
d'emporter une pile TLS pour deux requêtes optionnelles. Ce qui n'a pas pu être récupéré est
dit explicitement plutôt que laissé vide.

## Thème

Aucune couleur n'est codée en valeur absolue : nalarch n'utilise que les emplacements ANSI
du terminal et ne peint jamais son propre fond. Il suit donc le thème du terminal, clair
comme sombre, y compris lors d'un basculement à chaud.

Les fonds colorés (pastilles, ligne sélectionnée) passent par l'inversion vidéo : c'est la
seule façon d'obtenir un contraste correct sans connaître le thème actif. Un gris fixe
rendrait le texte discret illisible — gris sur gris — dès qu'on bascule.

## Mode `--demo`

```bash
nalarch --demo
```

Rejoue une session ressemblant à paru : invite de mot de passe, question `[O/n]`, barres
réécrites par retours chariot, compteurs, puis une compilation AUR sans avancement
chiffrable. **Aucune commande pacman n'est appelée, rien n'est installé ni supprimé.**

Ce n'est pas une simulation de l'interface : le script tourne réellement dans le
pseudo-terminal et traverse le même émulateur et la même analyse de flux que paru. Seule la
source du texte change. Sans quoi l'écran d'exécution serait intestable dès que le système
est à jour — c'est-à-dire la plupart du temps.

## Mode `--dump`

```bash
nalarch --dump [écran] [largeur] [hauteur]
```

Rend l'interface dans un tampon mémoire et l'écrit en texte brut, sans TTY. Utile pour
vérifier la mise en page, produire une capture, ou déboguer depuis un script.

| écran | contenu |
|---|---|
| `0`–`4` | les cinq onglets du tableau |
| `4` | écran de plan, comme si tout était coché |
| `5` | écran d'exécution (lance `pacman -Qi`, lecture seule) |
| `6` | tableau avec tout coché |
| `7` | exécution en cours, progression chiffrable |
| `8` | exécution en cours, compilation AUR (non chiffrable) |
| `9` | exécution terminée en échec |
| `17` | historique, sur la transaction la plus fournie (4ᵉ nombre = index) |
| `20` | l'onglet de recherche (`--query <terme>`, 4ᵉ nombre = quel résultat) |
| `21` | le plan d'installation de ce résultat, dépendances comprises |
| `22` | une transcription longue (4ᵉ nombre = premier événement, 5ᵉ = sortie brute) |
| `23` | la table de résolution de paru avec sa demande de confirmation |
| `24` | paru bloqué sur un choix de fournisseur |
| `25` | une compilation AUR, avec les séquences que makepkg émet vraiment |
| `26` | l'onglet Installés filtré sur une dépendance (`--query <nom>`) |
| `27` | une question numérotée déjà tapée (4ᵉ nombre : une invite de mot de passe) |
| `18` | plan de retour arrière construit à partir de celle-ci |
| `19` | sortie brute de paru en fin d'exécution (4ᵉ nombre = lignes remontées) |
